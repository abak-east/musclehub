# -*- coding: utf-8 -*-
"""
Created on Fri May 25 10:44:22 2018

MuscleHub A/B test

@author: LuisEd
"""
# Import libraries to analyze our 'example.db' database and perform operations.
import sqlite3
import pandas as pd
import numpy as np
from matplotlib import pyplot as plt
from scipy.stats import chi2_contingency

# Create a connection that represents the database.
conn = sqlite3.connect('example.db')

# Define a function that will take query as your SQL command parameter.
def sql_query(query):
    try:
        df = pd.read_sql(query, conn)
    except Exception as e:
        print(e.message)
    return df

# Examine the tables inserted into 'example.db' by codecademySQL.py.
# print(sql_query("""SELECT * FROM visits LIMIT 5"""))
# print(sql_query("""SELECT * FROM fitness_tests LIMIT 5"""))
# print(sql_query("""SELECT * FROM applications LIMIT 5"""))
# print(sql_query("""SELECT * FROM purchases LIMIT 5"""))

# Define a variable that will register visits on and after '7-1-17'.
visits_abtest = sql_query("""SELECT * FROM visits WHERE visit_date >= '7-1-17'""")

# Define a variable that will hold a series of LEFT JOINs to combine all tables.
tables_combined = sql_query("""
                            SELECT visits.first_name,
                            visits.last_name,
                            visits.visit_date,
                            fitness_tests.fitness_test_date,
                            applications.application_date,
                            purchases.purchase_date
                            FROM visits
                            LEFT JOIN fitness_tests
                              ON fitness_tests.first_name = visits.first_name
                              AND fitness_tests.last_name = visits.last_name
                              AND fitness_tests.email = visits.email
                            LEFT JOIN applications
                              ON applications.first_name = visits.first_name
                              AND applications.last_name = visits.last_name
                              AND applications.email = visits.email
                            LEFT JOIN purchases
                              ON purchases.first_name = visits.first_name
                              AND purchases.last_name = visits.last_name
                              AND purchases.email = visits.email
                            WHERE visits.visit_date >= '7-1-17'
                            """)
# print(len(tables_combined))

# Create a new table called 'ab_test_group' that stores values of 'A' if fitness_test_date is not null and 'B' otherwise.
tables_combined['ab_test_group'] = tables_combined.fitness_test_date.apply(lambda x: 'A' if pd.notnull(x) else 'B')

# Count how many 'A's and 'B's are in each group.
ab_counts = tables_combined.groupby(['ab_test_group']).first_name.count().reset_index()
# print(ab_counts)

# Temporary rename of column 'first_name' to 'counts' for the presentation.
'''
ab_counts.rename(columns={
'first_name': 'counts'
},
inplace=True)
'''

# Let's suppose that we don't know the values for A and B, we can extract them using the following:
group_A_counts = np.array(ab_counts.iloc[0])
groupA = group_A_counts[1]
# print(groupA)
group_B_counts = np.array(ab_counts.iloc[1])
groupB = group_B_counts[1]
# print(groupB)

# Create a pie chart to represent the percentage of A and B.
# Important: Save the figure before showing it or it will save a blank image.
plt.pie(ab_counts['first_name'], labels = ab_counts['ab_test_group'], autopct='%0.2f%%')
plt.axis('equal')
plt.savefig('ab_test_pie_chart.png')
plt.show()

# Create a new column called 'is_application' which is Application if application_date is not None and No Application, otherwise.
tables_combined['is_application'] = tables_combined.application_date.apply(lambda x: 'Application' if pd.notnull(x)\
               else 'No Application')
print(tables_combined.head())

# For group A and group B. Count how many Application and No Application are.
app_counts = tables_combined.groupby(['ab_test_group', 'is_application']).first_name.count().reset_index()
# print(app_counts)

# Pivot app_counts, such as the index is ab_test_group and the columns are is_application.
app_pivot = app_counts.pivot(columns='is_application', index='ab_test_group', values='first_name').reset_index()
# print(app_pivot)

# Define a new column called 'Total' which is the sum of Application and No Application.
app_pivot['Total'] = app_pivot.Application + app_pivot['No Application']
# print(app_pivot)

app_pivot['Percent with Application'] = app_pivot.Application / app_pivot.Total
print(app_pivot)

# Check if the results are significantly different from each other.
groupA_app_count = np.array(app_pivot.iloc[0])
groupB_app_count = np.array(app_pivot.iloc[1])
groupA_app = groupA_app_count[1]
groupA_Not_app = groupA_app_count[2]
groupB_app = groupB_app_count[1]
groupB_Not_app = groupB_app_count[2]

X = [[groupA_app, groupA_Not_app], [groupB_app, groupB_Not_app]]
print(X)
chi2, pval, dof, expected = chi2_contingency(X)
print(pval)

# Add a column to tables_combined called is_member which is Member if purchase_date is not None, and Not Member otherwise.
tables_combined['is_member'] = tables_combined.purchase_date.apply(lambda x: 'Member' if pd.notnull(x) else 'Not Member')
# print(tables_combined.head())

# Calculate how many applicants from each group are members.
just_apps = tables_combined[tables_combined.is_application == 'Application']
# print(just_apps.head())
just_apps_groupby = just_apps.groupby(['ab_test_group', 'is_member']).first_name.count().reset_index()
member_pivot = just_apps_groupby.pivot(columns='is_member', index='ab_test_group', values='first_name').reset_index()
# print(member_pivot)

# Calculate the percentage of members from each group.
member_pivot['Total'] = member_pivot.Member + member_pivot['Not Member']
member_pivot['Percent member'] = member_pivot.Member / member_pivot.Total
print(member_pivot)

# Are these significantly different from each other?
groupA_app_member = np.array(member_pivot.iloc[0])
groupB_app_member = np.array(member_pivot.iloc[1])
groupA_member = groupA_app_member[1]
groupA_Not_member = groupA_app_member[2]
groupB_member = groupB_app_member[1]
groupB_Not_member = groupB_app_member[2]

Y = [[groupA_member, groupA_Not_member], [groupB_member, groupB_Not_member]]
print(Y)
chi2, pval2, dof, expected = chi2_contingency(Y)
print(pval2)

# Now do the same, but get the total amount of visitors, instead of only those who filled out an application.
all_apps = tables_combined.groupby(['ab_test_group', 'is_member']).first_name.count().reset_index()
final_member_pivot = all_apps.pivot(columns='is_member', index='ab_test_group', values='first_name').reset_index()
final_member_pivot['Total'] = final_member_pivot.Member + final_member_pivot['Not Member']
final_member_pivot['Percent member'] = final_member_pivot.Member / final_member_pivot.Total
print(final_member_pivot)

groupA_all_member = np.array(final_member_pivot.iloc[0])
groupB_all_member = np.array(final_member_pivot.iloc[1])
groupA_members = groupA_all_member[1]
groupA_Not_members = groupA_all_member[2]
groupB_members = groupB_all_member[1]
groupB_Not_members = groupB_all_member[2]

Z = [[groupA_members, groupA_Not_members], [groupB_members, groupB_Not_members]]
print(Z)
chi2, pval3, dof, expected = chi2_contingency(Z)
print(pval3)

""" Create a bar chart that will show the following results:
    - Percent of visitors who apply
    - Percent of applicants who purchase a membership
    - Percent of visitors who purchase a membership
"""
# Percent of visitors who apply.
ax = plt.subplot()
plt.bar(range(len(app_pivot)), app_pivot['Percent with Application'].values)
ax.set_xticks(range(len(app_pivot)))
ax.set_xticklabels(['Fitness Test', 'No Fitness Test'])
ax.set_yticks([0, 0.05, 0.10, 0.15, 0.20])
ax.set_yticklabels(['0%', '5%', '10%', '15%', '20%'])
plt.savefig('percent_visitors_apply.png')
plt.show()

# Percent of applicants who purchase a membership.
ax = plt.subplot()
plt.bar(range(len(member_pivot)), member_pivot['Percent member'].values)
ax.set_xticks(range(len(member_pivot)))
ax.set_xticklabels(['Applicants purchase', 'Applicants No purchase'])
ax.set_yticks([0.40, 0.50, 0.60, 0.70, 0.80, 0.90])
ax.set_yticklabels(['40%', '50%', '60%', '70%', '80%', '90%'])
plt.savefig('percent_apply_purchase.png')
plt.show()

# Percent of visitors who purchase a membership.
ax = plt.subplot()
plt.bar(range(len(final_member_pivot)), final_member_pivot['Percent member'].values)
ax.set_xticks(range(len(final_member_pivot)))
ax.set_xticklabels(['Visitors purchased', 'Visitors No purchased'])
ax.set_yticks([0, 0.05, 0.10, 0.15, 0.20])
ax.set_yticklabels(['0%', '5%', '10%', '15%', '20%'])
plt.savefig('percent_visitors_purchase.png')
plt.show()